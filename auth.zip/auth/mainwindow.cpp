#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>

const QString USER = "user";
const QString PASSWORD = "123456789";

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_b_signIn_clicked()
{
    QString username = ui->le_login->text();
    QString password = ui->le_password->text();
    if(username == USER and password == PASSWORD){
        QMessageBox::information(this,"Log In","Success!");
    }
    else if(username == USER and password != PASSWORD){
        QMessageBox::warning(this,"Log In","Password is unused");
    }
    else if(username != USER and password == PASSWORD){
        QMessageBox::warning(this,"Log In","Login is unused");
    }
    else{
        QMessageBox::warning(this,"Log In","You Failed!");
    };
}


void MainWindow::on_b_close_clicked()
{
    QMessageBox::StandardButton reply = QMessageBox::question(this,"quit","Do you want to exit the programm", QMessageBox::Yes|QMessageBox::No);
    if(reply == QMessageBox::Yes){
        QApplication::quit();
    }
    else{
        qDebug("User asked No");
    }
}

